package jurgen.example.moviecatalogue4.support;

public interface MyAsyncCallback {
    void onPreExecute();
    void onPostExecute(FavoriteSupport favoriteSupport);
}
