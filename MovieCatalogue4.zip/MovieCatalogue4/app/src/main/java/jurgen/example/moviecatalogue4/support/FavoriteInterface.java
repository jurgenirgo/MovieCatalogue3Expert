package jurgen.example.moviecatalogue4.support;

public interface FavoriteInterface {
    void setFavoriteData(FavoriteSupport favoriteData);
}
